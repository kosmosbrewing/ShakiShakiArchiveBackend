<script setup lang="ts">
import { ref, reactive } from "vue";
import { Button } from "./ui/button";
import { Card, CardHeader, CardContent, CardFooter } from "./ui/card";
import { Input } from "./ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-vue-next";

interface ContactFormeProps {
  firstName: string;
  lastName: string;
  email: string;
  subject: string;
  message: string;
}

const contactForm = reactive<ContactFormeProps>({
  firstName: "",
  lastName: "",
  email: "",
  subject: "OUTERWEAR",
  message: "",
});

const invalidInputForm = ref<boolean>(false);

const handleSubmit = () => {
  const { firstName, lastName, email, subject, message } = contactForm;
  console.log(contactForm);

  const mailToLink = `mailto:leomirandadev@gmail.com?subject=${subject}&body=Hello I am ${firstName} ${lastName}, my Email is ${email}. %0D%0A${message}`;

  window.location.href = mailToLink;
};
</script>

<template>
  <section id="contact" class="container max-w-[550px] py-10 pt-20">
    <!-- form -->
    <Card class="bg-muted/5 dark:bg-card">
      <CardHeader class="text-primary text-center text-md">로그인</CardHeader>
      <CardContent>
        <form @submit.prevent="handleSubmit" class="grid gap-4">
          <div class="flex flex-col w-full gap-1.5">
            <Input
              id="first-name"
              type="text"
              placeholder="Please enter your ID"
              v-model="contactForm.firstName"
            />
          </div>

          <div class="flex flex-col w-full gap-1.5">
            <Input
              id="last-name"
              type="currency"
              placeholder="Please enter your PW"
              v-model="contactForm.lastName"
            />
          </div>

          <Alert v-if="invalidInputForm" variant="destructive">
            <AlertCircle class="w-4 h-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>
              There is an error in the form. Please check your input.
            </AlertDescription>
          </Alert>

          <router-link to="/signup" class="mt-3 w-full">
            <Button class="w-full">로그인</Button>
          </router-link>

          <router-link to="/signup" class="w-full">
            <Button class="w-full">회원가입</Button>
          </router-link>
        </form>
      </CardContent>

      <CardFooter></CardFooter>
    </Card>
  </section>
</template>
