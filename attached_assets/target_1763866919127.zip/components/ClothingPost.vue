<script setup lang="ts">
import { ref, reactive } from "vue";
import { Button } from "./ui/button";
import { Card, CardHeader, CardContent, CardFooter } from "./ui/card";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

import { AlertCircle, Building2, Phone, Mail, Clock } from "lucide-vue-next";

interface ContactFormeProps {
  firstName: string;
  lastName: string;
  email: string;
  subject: string;
  message: string;
}

const contactForm = reactive<ContactFormeProps>({
  firstName: "",
  lastName: "",
  email: "",
  subject: "OUTERWEAR",
  message: "",
});

const invalidInputForm = ref<boolean>(false);

const handleSubmit = () => {
  const { firstName, lastName, email, subject, message } = contactForm;
  console.log(contactForm);

  const mailToLink = `mailto:leomirandadev@gmail.com?subject=${subject}&body=Hello I am ${firstName} ${lastName}, my Email is ${email}. %0D%0A${message}`;

  window.location.href = mailToLink;
};
</script>

<template>
  <section id="contact" class="container py-10 sm:py-20">
    <!-- form -->
    <Card class="bg-muted/20 dark:bg-card">
      <CardHeader class="text-primary text-2xl"> </CardHeader>
      <CardContent>
        <form @submit.prevent="handleSubmit" class="grid gap-4">
          <div class="flex flex-col md:flex-row gap-8">
            <div class="flex flex-col w-full gap-1.5">
              <Label for="first-name">의류 명칭</Label>
              <Input
                id="first-name"
                type="text"
                placeholder="COZY SWEAT JACKET MELANGE GREY"
                v-model="contactForm.firstName"
              />
            </div>

            <div class="flex flex-col w-full gap-1.5">
              <Label for="last-name">금액</Label>
              <Input
                id="last-name"
                type="currency"
                placeholder="150000"
                v-model="contactForm.lastName"
              />
            </div>
          </div>

          <div class="flex flex-col gap-1.5">
            <Label for="email">TEMP</Label>
            <Input
              id="email"
              type="text"
              placeholder="TEMP"
              v-model="contactForm.email"
            />
          </div>

          <div class="flex flex-col gap-1.5">
            <Label for="subject">항목</Label>

            <Select v-model="contactForm.subject">
              <SelectTrigger>
                <SelectValue placeholder="Select a subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="OUTERWEAR"> OUTERWEAR </SelectItem>
                  <SelectItem value="TOP"> TOP </SelectItem>
                  <SelectItem value="BOTTOM"> BOTTOM </SelectItem>
                  <SelectItem value="DRESS"> DRESS </SelectItem>
                  <SelectItem value="ACCESSORY"> ACCESSORY </SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>

          <div class="flex flex-col gap-1.5">
            <Label for="message">정보</Label>
            <Textarea
              id="message"
              placeholder="Your message..."
              rows="5"
              v-model="contactForm.message"
            />
          </div>

          <Alert v-if="invalidInputForm" variant="destructive">
            <AlertCircle class="w-4 h-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>
              There is an error in the form. Please check your input.
            </AlertDescription>
          </Alert>

          <Button class="mt-4">등록하기</Button>
        </form>
      </CardContent>

      <CardFooter></CardFooter>
    </Card>
  </section>
</template>
