<template>
  <Hero />
  <Team />
</template>

<script setup lang="ts">
import Hero from "@/components/Hero.vue";
import Team from "@/components/Team.vue";
</script>
